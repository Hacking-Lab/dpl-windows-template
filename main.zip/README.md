# EDR Bypass Lab

# install-script.ps1
* DPL will load and run this script before making an Azure Snapshot

# post-install-script.ps1
* HL will run this script after booting the Azure Deployment from the Snapshot
* Please deploy your dynamic flags by modifying this script

